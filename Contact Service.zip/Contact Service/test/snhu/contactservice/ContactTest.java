package snhu.contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	
	/// Testing the getter methods
	@Test
	public void testContactClass() {
		Contact contact = new Contact("1234567890", "Hayden", "Gentry", "1234567890", "123 Main St.");
        assertEquals("1234567890", contact.getId());
        assertEquals("Hayden", contact.getFirstName());
        assertEquals("Gentry", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Main St.", contact.getAddress());
	}
	
	/// Testing the fields max values
	@Test
	public void testContactFieldsMaxValues() {
    	assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Hayden", "Gentry", "1234567890", "123 Main St."));
    	assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "12345678901", "Gentry", "1234567890", "123 Main St"));
    	assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Hayden", "12345678901", "1234567890", "123 Main St"));
    	assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Hayden", "Gentry", "1234567890", "1234567890123456789012345678901"));
	}
    
	/// Testing the phone number is 10 digits
    @Test
    public void testPhoneNumberNot10() {       
    	assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Hayden", "Gentry", "12345678901", "123 Main St"));
    	assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "Hayden", "Gentry", "123456789", "123 Main St"));
    }
    
    /// Testing the fields for null values
    @Test 
    public void testIfContactFieldsNull() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Null", "Null", "1234567890", "Null St."));
        assertThrows(IllegalArgumentException.class, () -> new Contact("Null", null, "Null", "1234567890", "Null St."));
        assertThrows(IllegalArgumentException.class, () -> new Contact("Null", "Null", null, "1234567890", "Null St."));
        assertThrows(IllegalArgumentException.class, () -> new Contact("Null", "Null", "Null", null, "Null St."));
        assertThrows(IllegalArgumentException.class, () -> new Contact("Null", "Null", "Null", "1234567890", null));
    }
}