package snhu.contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

	/// Test Add Contact. If contact ID already exists throw error
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact1 = new Contact("1234567890", "Hayden", "Gentry", "1234567890", "123 Main St.");
        contactService.addContact(contact1);
        assertNotNull(contactService.getContact("1234567890"));
        Contact contact2 = new Contact("1234567890", "Jane", "Buck", "0987654321", "456 Broadway");
        /// Duplicate contact ID throw error
    	assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact2));
    }
    
    /// Test Delete Contact. If contact does not exist throw error
    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "Hayden", "Gentry", "1234567890", "123 Main St.");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContact("1234567890"));
        /// Contact does not exist throw error
    	assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("0987654321"));
    }

    /// Test Update Contact. If contact does not exist throw error
    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1234567890", "Hayden", "Gentry", "1234567890", "123 Main St.");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", "Jane", "Buck", "0987654321", "456 Broadway");
        assertNotNull(contactService.getContact("1234567890"));
        assertEquals("1234567890", contact.getId());
        assertEquals("Jane", contact.getFirstName());
        assertEquals("Buck", contact.getLastName());
        assertEquals("0987654321", contact.getPhoneNumber());
        assertEquals("456 Broadway", contact.getAddress());
        /// Contact does not exist throw error
    	assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("0987654321", "Dolly", "Parton", "1234512345", "Tennessee"));
    }
}