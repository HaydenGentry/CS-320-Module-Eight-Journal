package snhu.contactservice;

public class Contact {
    final private String id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;
    
	/// Contact fields constraints. If not within constraints throw error
    public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
    	if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Contact ID cannot be null or exceed 10 characters.");
        }
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name cannot be null or exceed 10 characters.");
        }
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot be null or exceed 10 characters.");
        }
        if (phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Phone number cannot be null and must be 10 digits.");
        }
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address cannot be null or exceed 30 characters.");
        }

        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    /// Getter Methods
    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public String getAddress() {
        return address;
    }
    
    /// Setter Methods
    public void setFirstName(String value) {
    	firstName = value;
    }

    public void setLastName(String value) {
    	lastName = value;
    }
    
    public void setPhoneNumber(String value) {
    	phoneNumber = value;
    }
    
    public void setAddress(String value) {
    	address = value;
    }
}