package snhu.contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<>();
    }
    
    /// Check ID is unique before adding to contacts. If ID is not unique throw error
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        else {
        	contacts.put(contact.getId(), contact);
        }
    }
    
    /// Delete a contact. If the contact does not exist throw error
    public void deleteContact(String contactId) {
    	if (contacts.containsKey(contactId)) {        
    		contacts.remove(contactId);	
        }
        else {
            throw new IllegalArgumentException("Cannot remove a contact that does not exist.");
        }
    }
    
    /// Update a contact. If the contact does not exist throw error
    public void updateContact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
        	contact.setFirstName(firstName);
            contact.setLastName(lastName);
            contact.setPhoneNumber(phoneNumber);
            contact.setAddress(address);
        }
        else {
            throw new IllegalArgumentException("Must add a contact before you can update it.");
        }
    }

    /// Getter method
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}